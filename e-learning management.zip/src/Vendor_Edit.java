

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Vendor_Edit
 */
@WebServlet("/Vendor_Edit")
public class Vendor_Edit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Vendor_Edit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter pw=response.getWriter();
		String age=request.getParameter("age");
		String contact=request.getParameter("phone");
		String address=request.getParameter("address");
		String email=request.getParameter("email");
		String pass=request.getParameter("password");
		String approval=request.getParameter("approval");
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/amrutha","root","password-1");
			Statement stmt = conn.createStatement();
	        ResultSet rs=stmt.executeQuery("select * from vendor");
	        PreparedStatement ps=null;
	        int i=0;
	        while(rs.next()){
	        	if(rs.getString(5).equals(email)){
	        		ps=conn.prepareStatement("update vendor set age=?,contact=?, Address=?,password=?,approval=?");
	        		ps.setString(1,age);
	        		ps.setString(2, contact);
	        		ps.setString(3, address);
	        		ps.setString(4, pass);
	        		ps.setString(5, approval);
	        		break;
	        	}
	        }
	        i=ps.executeUpdate();
	        if(i!=0){
	        	response.sendRedirect("Data_Editted.html");
	        }
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
