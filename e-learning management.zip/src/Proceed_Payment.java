

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Proceed_Payment
 */
@WebServlet("/Proceed_Payment")
public class Proceed_Payment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Proceed_Payment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		String pay=request.getParameter("payment");
		String s,s1;
		ServletContext context=getServletContext();
		context.setAttribute("pay", pay);
		
        s=(String)context.getAttribute("email");  
        s1=(String)context.getAttribute("id");
//        pw.println(s+" "+s1);
        try{
        	Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/amrutha","root","password-1");
			PreparedStatement ps = conn.prepareStatement("update user_registered set feestatus=? where username='"+s+"' && courseid='"+s1+"'");
			ps.setString(1, "yes");
			int i=ps.executeUpdate();
			if(i!=0){
				response.sendRedirect("Proceed_Payment.jsp");
				pw.println("<h1>Payment done by "+pay+"</h1>");
			}
        }catch(Exception e){
        	e.printStackTrace();
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
